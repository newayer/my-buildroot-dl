# Security Policy

## Reporting a vulnerability

If you want to report a security issue, please use [huntr.dev](https://huntr.dev/bounties/disclose?target=https%3A%2F%2Fgithub.com%2Fvim%2Fvim) to privately disclose the issue to us.
They also have rewards in the form of money, swag and CVEs.

**Please don't publicly disclose the issue until it has been addressed by us.**
