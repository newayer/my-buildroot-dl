#ifndef E2TOOLS_COPY_H
#define E2TOOLS_COPY_H

extern long copy(int argc, char *argv[]);
extern int my_strcmp(const void *n1, const void *n2);

#endif /* !E2TOOLS_COPY_H */
