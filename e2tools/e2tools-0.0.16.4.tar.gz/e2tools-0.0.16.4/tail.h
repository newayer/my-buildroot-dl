#ifndef E2TOOLS_TAIL_H
#define E2TOOLS_TAIL_H

extern long do_tail(int argc, char *argv[]);

#endif /* !E2TOOLS_TAIL_H */
