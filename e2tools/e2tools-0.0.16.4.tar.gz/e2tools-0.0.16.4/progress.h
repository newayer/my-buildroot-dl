#ifndef E2TOOLS_PROGRESS_H
#define E2TOOLS_PROGRESS_H

void init_progress(char *file, struct stat *sbuf);

#endif /* !E2TOOLS_PROGRESS_H */
