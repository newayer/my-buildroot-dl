import numpy
import numpy_demo

a = numpy.array([1.0, 3.5, 8.4, 2.3, 6.6, 4.1], "d")
numpy_demo.sum_of_squares(a)
