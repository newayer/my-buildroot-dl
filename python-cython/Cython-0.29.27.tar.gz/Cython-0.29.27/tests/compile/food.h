struct Tomato {
	PyObject_HEAD
};

struct Bicycle{
	PyObject_HEAD
};

