/*
 * Copyright 2014, Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

void get_sys_info(struct sys_info *sys_info);
