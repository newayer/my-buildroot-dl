var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Modules",url:"modules.html"}]}
