===============================
 openvpn examples
===============================
-------------------------
 Secure IP tunnel daemon
-------------------------

:Manual section: 5
:Manual group: Configuration files


INTRODUCTION
============

This man page gives a few simple examples to create OpenVPN setups and configuration files.

.. include:: man-sections/examples.rst
