.. _aiohttp_changes:

=========
Changelog
=========

To be included in v\ |release| (if present)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. towncrier-draft-entries:: |release| [UNRELEASED DRAFT]

Released versions
^^^^^^^^^^^^^^^^^

.. include:: ../CHANGES.rst

.. include:: ../HISTORY.rst
