0. Reviewed guide and contributing documents? (Yes/No):
1. version [x.y.z, hash, other]: 
2. installed as a package or compiled from sources [deb, rpm, git, other]: 
3. standalone or part of third party [motion, MotionEyeOS, other]: 
4. video stream source [V4L (card or USB), net cam (mjpeg, rtsp, other), mmal]: 
5. hardware [x86, ARM, other]: 
6. operating system [16.04, Stretch, etc, FreeBSD, other]: 

