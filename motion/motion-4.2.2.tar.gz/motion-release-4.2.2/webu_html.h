#ifndef _INCLUDE_WEBU_HTML_H_
#define _INCLUDE_WEBU_HTML_H_


void webu_html_badreq(struct webui_ctx *webui);
void webu_html_main(struct webui_ctx *webui);

#endif
