#include "IAndroidShm.h"
#include "BpAndroidShm.h"

namespace android{
	IMPLEMENT_META_INTERFACE(AndroidShm, "com.samsung.android.jam.IAndroidShm");
};
