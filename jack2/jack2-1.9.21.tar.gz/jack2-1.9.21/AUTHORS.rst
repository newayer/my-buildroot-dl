Authors
#######
(Ordered alphabetically)

Adrian Knoth
Alba Mendez
Alexander Graf
Alexandre Prokoudine
Alexandru Tofan
Andreas Müller
Andrew Kelley
Andrzej Szombierski
Andy Wingo
Anthony Van Groningen
Arnout Diels
Arnaud Rebillout
Arnold Krille
Bernhard M. Wiedemann
Bruno Vernay
Cédric Schieli
Chris Caudle
David Garcia Garzon
David Robillard
David Runge
Deven Lahoti
Devin Anderson
Dmitry Baikov
Edward Betts
Eliot Blennerhassett
Fernando Lopez-Lezcano
Filipe Coelho <falktx@falktx.com>
Florian Faber
Francis Pinteric
Gabriel M. Beddingfield
Gaël Portay
Holger Dehnhardt
Hunter L. Allen
Ian Esten
Jacek Konieczny
Jack O'Quin
James Cowgill
James P. Thomas
Jan Engelhardt
Jaroslav Kysela
Jeremy Hall
John Emmas
Johnny Petrantoni
Jonathan Woithe
Josh Green
Joshua Moyerman
Julien Acroute
Jussi Laako
Juuso Alasuutari
Kai Vehmanen
Karl Lindén
Karsten Wiese
Kim Jeong Yeon
Kjetil S. Matheussen
Lars-Peter Clausen
Lee Revell
Maks Naumov
Marc-Olivier Barre
Mario Lang
Markus Seeber
Matt Flax
Matthias Geier
Maxim Grishin
Melanie Thielker
Michael Voigt
Michał Szymański
Nedko Arnaudov
Olaf Hering
Olivier Humbert
Paul Davis
Peter Bridgman
Peter L Jones
Pieter Palmers
Ricardo Crudo
Robert Ham
Robin Gareus
Rohan Drape
Romain Moret
Rui Nuno Capela
Samuel Martin
Samuel Tracol
Stefan Schwandter
Stéphane Letz <letz@grame.fr>
Steve Harris
Steven Chamberlain
Taybin Rutkin
Thibault LeMeur
Thomas Brand <tom@trellis.ch>
Thomas Petazzoni
Thom Johansen
Tilman Linneweh
Tim Blechmann
Timo Wischer
Tom Szilagyi
Torben Hohn
Valentin David
Valerio Pilo
Viktor Wilhelmsson
Yasuhiro Fujii
Youri Westerman
