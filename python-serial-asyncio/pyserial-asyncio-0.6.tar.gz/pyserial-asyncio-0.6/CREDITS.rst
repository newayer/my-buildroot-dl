=========
 Credits
=========

Main authors of pySerial-asyncio
================================

- Chris Liechti (zsquareplusc)
- Robert Smallshire (rob-smallshire)


Contributors
============

- David Ko
- Nicolas Di Pietro
- jabdoa2
- Chris Seymour
- ... not all names may be listed here, see also ``git log`` or online history_


.. _history: https://github.com/pyserial/pyserial-asyncio/commits/master
