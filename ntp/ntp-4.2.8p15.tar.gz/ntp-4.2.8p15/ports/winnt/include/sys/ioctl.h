/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for NTP package
 **************************************************************/

#ifndef _IOCTL_H
#define _IOCTL_H

#include "win32_io.h"

#endif