/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2007 - 2016 Realtek Corporation. All rights reserved. */

#ifndef __HAL_PHY_REG_H__
#define __HAL_PHY_REG_H__

/* for PutRFRegsetting & GetRFRegSetting BitMask
 * #if (RTL92SE_FPGA_VERIFY == 1)
 * #define		bRFRegOffsetMask	0xfff
 * #else */
#define		bRFRegOffsetMask	0xfffff
/* #endif */

#endif /* __HAL_PHY_REG_H__ */
