swupdate-hawkbitcfg
===================

swupdate-hawkbitcfg is a small tool that tries to connect to a running instance
of SWUpdate and configures hawkBit's parameter.

SYNOPSIS
--------

swupdate-hawkbitcfg [option]

DESCRIPTION
-----------

-h
        help
-p
        allows to set the polling time (in seconds)
-e
        enable suricatta mode
-d
        disable suricatta mode
