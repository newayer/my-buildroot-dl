require("scimark_lib").LU(100)(tonumber(arg and arg[1]) or 5000)
