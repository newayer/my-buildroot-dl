require("scimark_lib").SPARSE(1000, 5000)(tonumber(arg and arg[1]) or 150000)
