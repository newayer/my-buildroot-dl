do --- charpattern
  assert(type(utf8.charpattern) == 'string')
end
