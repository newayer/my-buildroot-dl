require("scimark_lib").SOR(100)(tonumber(arg and arg[1]) or 50000)
