require("scimark_lib").FFT(1024)(tonumber(arg and arg[1]) or 50000)
