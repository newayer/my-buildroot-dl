============
Installation
============

At the command line::

    $ easy_install PyCRC

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv PyCRC
    $ pip install PyCRC
