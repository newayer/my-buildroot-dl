#ifndef TEST_EBITMAP_H__
#define TEST_EBITMAP_H__

#include <CUnit/Basic.h>

int ebitmap_test_init(void);
int ebitmap_test_cleanup(void);
int ebitmap_add_tests(CU_pSuite suite);

#endif  /* TEST_EBITMAP_H__ */
