#ifndef _SEPOL_USER_INTERNAL_H_
#define _SEPOL_USER_INTERNAL_H_

#include <sepol/user_record.h>
#include <sepol/users.h>

#endif
